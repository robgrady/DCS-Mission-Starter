"""BB-1..3: airfield dressing — parked aircraft on real parking spots, ground support
equipment near occupied stands, infrastructure statics near the ramp.

Parked AIRCRAFT are placed as UNCONTROLLED flights at the terrain's own parking
slots — NOT as static objects. This is the only way to get them oriented
correctly: the DCS terrain stores each slot's parking heading in its binary and
applies it when the sim spawns an aircraft there; that heading is NOT exposed to
static placement (pydcs ParkingSlot has no heading field), so a static must guess
its facing and can also clip a building's collision mesh. An uncontrolled flight
lets DCS own both position and heading — nose-out, ready to taxi — exactly like
the AI flights that already spawn correctly. Ground equipment stays static."""
import math
import random
from dcs import mapping
from dcs.mission import StartType
import dcs.statics as statics

from .resolver import resolve, load_json
from .placement import AirfieldKeepOut

DENSITY_FILL = {"sparse": 0.25, "normal": 0.45, "busy": 0.70}
# Two ways to place parked aircraft — a genuine tradeoff (pydcs does NOT expose
# the terrain's true parking heading, so there is no free lunch):
#   "static"    — static objects. Instant render, cheap, inert, no radar
#                 contacts, no spawn-in pop-in. Facing is a best-effort per-slot
#                 guess (rows via geometry, nose toward the runway).
#   "parked_ai" — uncontrolled flights at real slots. DCS owns facing (exact,
#                 nose-out) and placement, but they cost FPS, appear as map
#                 contacts, and STREAM IN over the first seconds ("pop-in").
# Static is the default — the right tool for inert ramp clutter. The auto/
# density cap is per field and depends on mode; explicit fill % overrides it.
AUTO_CAP_PER_FIELD = {
    "static":    {"sparse": 10, "normal": 18, "busy": 28},
    "parked_ai": {"sparse": 5,  "normal": 8,  "busy": 14},
}


def resolve_theme(era, side, map_preset=None, theme_key=None, warnings=None):
    """Pick the ramp theme for a side: explicit choice > map preset > era default.

    Themes are era-gated by structure (a theme only exists under its era), so a
    WWII field can never draw a modern ramp no matter what the user selects."""
    themes = load_json("ramp_themes").get(era, {}).get(side, {})
    default_key = themes.get("default")
    key = theme_key or (map_preset or {}).get(f"{side}_theme") or default_key
    if key not in themes or key == "default":
        if theme_key and warnings is not None:
            warnings.append(f"ramp theme '{theme_key}' does not exist in the "
                            f"{era} era - using '{default_key}'")
        key = default_key
    return key, themes.get(key)


def _weighted(rng, pairs):
    """Pick from [[ref, weight], ...] or [[ref, weight, [liveries]], ...].
    Returns (ref, livery_or_None). Unknown livery ids are harmless: DCS
    falls back to the default skin."""
    idx = rng.choices(range(len(pairs)), weights=[p[1] for p in pairs], k=1)[0]
    p = pairs[idx]
    livery = rng.choice(p[2]) if len(p) > 2 and p[2] else None
    return p[0], livery


def _offset(pos, meters, bearing_deg):
    b = math.radians(bearing_deg)
    return mapping.Point(pos.x + meters * math.cos(b),
                         pos.y + meters * math.sin(b), pos._terrain)


def dress_airfield(m, airport, country, era_side_cfg, density, rng: random.Random,
                   used_slot_names=None, theme=None, fill=None,
                   include_aircraft=True, include_gse=True, include_infra=True,
                   aircraft_mode="static", field_heading=None):
    """Fill an airfield with era/faction-correct static aircraft + ground equipment.

    Placement discipline: aircraft go on surveyed parking stands only (always
    safe); everything free-placed (GSE, infrastructure) is validated against
    the runway keep-out corridors so movement areas stay clear.

    theme: ramp theme dict from ramp_themes.json (weighted [ref, weight] lists)
           deciding WHO parks here; falls back to eras.json flat lists.
    fill: 0-100 percent of free stands to fill; None derives from density.
    include_*: user-selected object classes (aircraft / GSE / infrastructure).
    """
    used = used_slot_names or set()
    keepout = AirfieldKeepOut(airport)
    placed = 0

    if theme:
        plane_w = theme["planes"]
        large_w = theme["large"]
        helo_w = theme["helos"]
    else:  # legacy flat lists, weight 1
        plane_w = [[r, 1] for r in era_side_cfg["parked_planes"]]
        large_w = [[r, 1] for r in era_side_cfg["parked_large"]]
        helo_w = [[r, 1] for r in era_side_cfg["parked_helos"]]
    large_set = {p[0] for p in large_w}
    fuel_truck = resolve(era_side_cfg["fuel_truck"])
    utility = [resolve(r) for r in era_side_cfg["utility_trucks"]]

    # ELIGIBLE stands only: the fill %% must mean "this share of the aircraft
    # spots actually get a static" — a helipad on a WWII field (no helos in
    # the era list) can never be filled, so it must not dilute the math
    def _can_fill(s):
        if s.airplanes:
            return bool(plane_w or large_w)
        return bool(helo_w)          # helo-only pad
    free = [s for s in airport.parking_slots
            if s.unit_id is None and s.slot_name not in used and _can_fill(s)]
    rng.shuffle(free)
    # best-effort per-slot facing (static mode only; AI mode lets DCS decide)
    slot_hdgs = keepout.slot_headings() if (free and aircraft_mode == "static") else {}

    if fill is not None:
        # EXPLICIT user percentage WINS - no cap. The user asked for 75%,
        # they get 75% (of eligible free stands), even at a 247-stand field.
        target = round(len(free) * max(0, min(100, fill)) / 100.0)
    else:
        target = min(int(len(free) * DENSITY_FILL[density]),
                     AUTO_CAP_PER_FIELD[aircraft_mode][density])

    for slot in (free if include_aircraft else []):
        if placed >= target:
            break
        # pick a type that fits the stand (helo lists can be empty, e.g. WWII)
        if slot.helicopter and not slot.airplanes:
            if not helo_w:
                continue
            ref, livery = _weighted(rng, helo_w)
        elif slot.large or (slot.airplanes and slot.length >= 60 and slot.width >= 55):
            # flagged-large stands, or physically roomy ramp spots (some
            # terrains, e.g. NTTR, flag no stands large at all — but Nellis
            # parks B-1s on its big ramp squares in reality)
            ref, livery = _weighted(rng, large_w + plane_w)
        elif slot.airplanes:
            # only put big airframes on large stands
            small = [p for p in plane_w if p[0] not in large_set]
            ref, livery = _weighted(rng, small or plane_w)
        else:
            if not helo_w:
                continue
            ref, livery = _weighted(rng, helo_w)
        if slot.unit_id is not None:      # claimed by player/ambient meanwhile
            continue
        unit_type = resolve(ref)

        if aircraft_mode == "parked_ai":
            # EXACT facing: an uncontrolled flight at the real slot. DCS aligns
            # it to the slot (the painted line) and seats it on valid parking —
            # can't face wrong or clip a building. Cost: it's an AI unit (FPS,
            # shows as a map contact, streams in over the first seconds).
            try:
                grp = m.flight_group_from_airport(
                    country, f"RAMP {airport.name} {slot.slot_name} {unit_type.id}",
                    unit_type, airport, start_type=StartType.Cold, group_size=1,
                    parking_slots=[slot])
            except Exception:
                continue                   # type can't park here — skip, no crash
            grp.uncontrolled = True        # inert: parked, never activates
            gse_ref_hdg = keepout.away_side_bearing(slot.position)
        else:
            # STATIC clutter: instant render, cheap, inert, no radar contact.
            # Facing priority:
            #   1. MEASURED field heading (parking_headings.json) — the real
            #      painted-line heading someone read in the Mission Editor. pydcs
            #      won't expose it, so a measured value is the exact answer for
            #      this field's majority apron. Use it for every static here.
            #   2. Per-slot geometric guess (rows via covariance, nose toward
            #      runway) where the field hasn't been measured yet.
            #   3. Runway-axis fallback.
            base_hdg = (field_heading if field_heading is not None
                        else slot_hdgs.get(slot.slot_name,
                                           keepout.runway_axis_heading()))
            heading = (base_hdg + rng.uniform(-3, 3)) % 360.0
            grp = m.static_group(
                country, f"ST {airport.name} {slot.slot_name} {unit_type.id}",
                _type=unit_type, position=slot.position, heading=heading)
            gse_ref_hdg = heading + rng.uniform(60, 120)
        if livery:
            grp.units[0].livery_id = livery
        placed += 1

        # BB-2: ground support equipment near ~half the occupied stands.
        # Stay WITHIN the stand's own footprint (stands are 40-80 m wide, so
        # 12-16 m off the aircraft is still apron, never the taxilane) and
        # never inside a runway corridor.
        if include_gse and rng.random() < 0.5:
            gse_max = max(12.0, min(16.0, (min(slot.length, slot.width) / 2) - 8))
            gse_pos = _offset(slot.position, rng.uniform(12, gse_max), gse_ref_hdg)
            if keepout.clear(gse_pos, avoid_stands=False):
                gse_type = fuel_truck if rng.random() < 0.5 else rng.choice(utility)
                m.static_group(country, f"GSE {airport.name} {slot.slot_name}",
                               _type=gse_type, position=gse_pos,
                               heading=rng.uniform(0, 360))

    # BB-3: infrastructure cluster near the ramp. The ramp sits BESIDE the
    # runway, so a random bearing from its centroid used to land the cluster
    # mid-runway. Now: push the anchor perpendicular to the runway axis,
    # DEEPER into the ramp side (away from the runway), then validate — the
    # cluster row runs parallel to the runway so it can never cross it.
    if free and include_infra:
        cx = sum(s.position.x for s in free) / len(free)
        cy = sum(s.position.y for s in free) / len(free)
        centroid = mapping.Point(cx, cy, airport.position._terrain)
        away = keepout.away_side_bearing(centroid)
        anchor = None
        for push in (300, 450, 600):
            cand = _offset(centroid, push, away + rng.uniform(-20, 20))
            if keepout.clear(cand, margin=60):
                anchor = cand
                break
        if anchor is None:
            anchor = keepout.find_clear(centroid, 300, 700, rng, margin=60,
                                        prefer_bearing=away)
        if anchor is not None:
            row = keepout.runway_axis_heading()   # row parallels the runway
            infra = [
                (statics.Fortification.Fuel_tank, 0),
                (statics.Fortification.Fuel_tank, 18),
                (statics.Fortification.Tent01, 60),
                (statics.Fortification.Tent03, 85),
                (statics.Fortification.Barracks_2, 130),
                (statics.Fortification.Comms_tower_M, 190),
            ]
            for i, (obj, dist) in enumerate(infra):
                pos = _offset(anchor, dist, row)
                if not keepout.clear(pos):
                    continue                      # belt and suspenders
                m.static_group(country, f"INF {airport.name} {i}", _type=obj,
                               position=pos, heading=(row + 90) % 360)

    return placed
